package ioexceptionsample;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class IOExceptionSample {
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("Masukkan nama anda: ");
        
        //Instansiasi objek BufferedReader
        BufferedReader baca = new BufferedReader (new InputStreamReader(System.in));
        String nama = null;
        
        try{
            nama = baca.readLine();
        } catch(IOException e){
            System.out.println("Gagal membaca data");
        }
        System.out.println("Nama anda adalah: " + nama);
    }
    
}
