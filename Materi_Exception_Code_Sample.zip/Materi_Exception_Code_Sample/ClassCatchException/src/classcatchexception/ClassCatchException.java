package classcatchexception;

public class ClassCatchException {

    public static void main(String[] args) {
        // TODO code application logic here
        try{
            Object object = new String("Edi Saputra");
            int angka = (Integer) object;
        } catch(ClassCastException e){
            System.out.println("Kesalahan type cast class");
        }
    }
    
}
