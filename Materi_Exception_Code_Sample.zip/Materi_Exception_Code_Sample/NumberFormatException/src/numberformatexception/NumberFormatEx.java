package numberformatexception;

import java.util.Scanner;

public class NumberFormatEx {

    public static void main(String[] args) {
        // TODO code application logic here
        String NIK;
        int numberNIK;
        
        Scanner input = new Scanner(System.in);
        NIK = input.next();
        
        try{
            numberNIK  = Integer.parseInt(NIK);
            System.out.println(numberNIK);
        } catch (NumberFormatException e) {
            System.out.println("NIK mengandung huruf");
        }
        
    }
    
}
