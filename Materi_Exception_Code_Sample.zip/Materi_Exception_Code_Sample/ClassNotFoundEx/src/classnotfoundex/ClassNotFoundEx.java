package classnotfoundex;

public class ClassNotFoundEx {

    public static void main(String[] args) {
        //coba mencari kelas String yang terdapat di Java
        try{
            Class kelas = Class.forName("java.lang.String");
            System.out.println("Kelas '" + kelas.getName() +"' ditemukan");
        } catch (ClassNotFoundException e){
            System.out.println("Kelas yang dicari tidak ditemukan");
        }
        
        //coba mencari kelas yang tidak ada
        try{
            Class kelas = Class.forName("java.lang.FakeString");
            System.out.println("Kelas '" + kelas.getName() +"' ditemukan");
        } catch (ClassNotFoundException e){
            System.out.println("Kelas yang dicari tidak ditemukan");
        }
    }
    
}
