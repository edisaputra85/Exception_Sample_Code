package trycatchfinally;
public class TryCatchFinally {
    public static void main(String[] args) {
        String[] nama = new String[2];
        nama[0] = "Adam";
        nama[1] = "Firman";
        
        try{
            System.out.println(nama[2]);
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Akses Array ke Indeks yang Salah");
        } finally {
            for (int i=0; i<2; i++){
                System.out.println(nama[i]);
            }
            System.out.println("Finally berjalan");
        }
    }
    
}
