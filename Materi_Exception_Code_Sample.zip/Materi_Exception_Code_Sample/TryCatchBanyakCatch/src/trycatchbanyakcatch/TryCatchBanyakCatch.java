package trycatchbanyakcatch;

import java.math.BigInteger;
import java.util.InputMismatchException;
import java.util.Scanner;

public class TryCatchBanyakCatch {

    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner (System.in);
        BigInteger x;
        BigInteger y;
        
        try{
            x = new BigInteger(String.valueOf(input.nextBigInteger()));
            y = new BigInteger(String.valueOf(input.nextBigInteger()));
            System.out.println(x.divide(y));
        } catch(ArithmeticException e1){
            System.out.println("Pembagian dengan 0");
        } catch(InputMismatchException e2){
            System.out.println("Input tidak bertipe BigInteger");
        }
    }
    
}
