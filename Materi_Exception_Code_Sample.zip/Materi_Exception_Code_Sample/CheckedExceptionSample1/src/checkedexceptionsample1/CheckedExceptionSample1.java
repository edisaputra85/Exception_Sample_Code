package checkedexceptionsample1;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
public class CheckedExceptionSample1 {
    public static void main(String[] args) {
        // TODO code application logic here
        File dataBinatang = new File ("C://databinatang.txt");
        try{
           FileReader baca = new FileReader(dataBinatang); 
        } catch(FileNotFoundException e){
            System.out.println("File tidak ditemukan");
        }      
    }   
}
