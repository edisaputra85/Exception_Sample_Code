package uncheckedexceptionsample1;
import java.util.Scanner;
public class UncheckedExceptionSample1 {
    public static void main(String[] args) {
        // TODO code application logic here
        String nama[] = {"Firman","Adam","Daniyal"};
        int maks;
        
        System.out.println("Inputkan jumlah array: ");
        Scanner input = new Scanner (System.in);
        maks = input.nextInt();
        
        try{
            for (int i=0; i<maks; i++){
            System.out.println(nama[i]);
            }   
        } catch(ArrayIndexOutOfBoundsException e){
            System.out.println("Indeks Array melebihi batas maks");
        }
        
    }    
}
