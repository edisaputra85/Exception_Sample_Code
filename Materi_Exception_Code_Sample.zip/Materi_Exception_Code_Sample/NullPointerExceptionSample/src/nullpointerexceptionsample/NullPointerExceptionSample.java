package nullpointerexceptionsample;

import java.util.Scanner;

public class NullPointerExceptionSample {

    public static void main(String[] args) {
        // TODO code application logic here
        String username = new String();
        Scanner input = new Scanner(System.in);
        username = input.nextLine();
        
        if (username.contains(" "))
            username = null;
        
        try{
            System.out.println(username.charAt(0));
        } catch (NullPointerException e) {
            System.out.println("Anda tidak memasukkan username dengan benar");
        }
    }
    
}
