package throwdanthrows;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;

public class ThrowDanThrows {

    public static void main(String[] args) {
        panggilFileBinatang();
        
        try{
            panggilFileTumbuhan();
        } catch (FileNotFoundException e){
            System.out.println("File data tumbuhan tidak ditemukan");
        }
    }
    
    public static void panggilFileBinatang(){
        File dataBinatang = new File ("C://databinatang.txt");
        try{
            FileReader baca = new FileReader(dataBinatang);
        } catch(FileNotFoundException e) {
            System.out.println("File data binatang tidak ditemukan");
        }
    }
    
    public static void panggilFileTumbuhan() throws FileNotFoundException{
        File dataTumbuhan = new File ("C://datatumbuhan.txt");
        FileReader baca = new FileReader(dataTumbuhan);
        //kita coba lempar secara sengaja exception walaupun data ditemukan
        throw new FileNotFoundException();
    }
}
