package arithmeticexception;
import java.math.BigDecimal;
import java.math.RoundingMode;

public class ArithmeticEx {

    public static void main(String[] args) {
        // TODO code application logic here
        BigDecimal x = new BigDecimal(22);
        BigDecimal y = new BigDecimal(7);
        
        try{
            System.out.println(x.divide(y));
        } catch (ArithmeticException e){
            System.out.println(x.divide(y,7,RoundingMode.CEILING));
        }
    }    
}
