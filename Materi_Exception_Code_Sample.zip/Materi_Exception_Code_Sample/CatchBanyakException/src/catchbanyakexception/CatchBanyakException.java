package catchbanyakexception;

import java.io.FileWriter;
import java.io.IOException;
import java.util.InputMismatchException;
import java.util.Scanner;

public class CatchBanyakException {

    public static void main(String[] args) throws IOException {
        Scanner input = new Scanner(System.in);
        int angka;
        
        try{
            angka = input.nextInt();
            FileWriter fw = new FileWriter ("dataAngka.txt");
            fw.write(String.valueOf(angka));
        } catch (IOException | InputMismatchException e){
            System.out.println(e);
        }
    }
    
}
